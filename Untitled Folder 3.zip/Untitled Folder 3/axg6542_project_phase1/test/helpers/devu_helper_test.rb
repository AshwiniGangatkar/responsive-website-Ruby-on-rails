require 'test_helper'

class DevuHelperTest < ActionView::TestCase
end
