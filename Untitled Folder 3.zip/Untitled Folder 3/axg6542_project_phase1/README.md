== README

	1.Server framework: I decided to work on Ruby on Rails. As I am not very proficient in coding yet, I 
	  thought ruby on rails is better to start with because of it's features that makes coding less and easy. Also, as Rails works on MVC framework, I'm getting a better and practical understanding of MVC pattern. So far, I'm finding it very interesting to work on.

	  	*Ruby version-1.9.3
	  	*Rails version-4.0.2


    2.Client framework: I chose jQuery because it was easy to learn. It's very simple providing required 
      action in few lines of code. I didn't want to jump directly to angularjs but will try to by the last phase of the project.

    3.Easy part of implementation: It was not easy to start with, but once setup is done, there were few lines 
      of code to write. Rails generated the whole structure. I could directly to jumo to code for client-side interface.

    4.Hard part of implementation: Hard part was installing and setting up so many new things and getting use to 
      it. Process of installing ruby on rails may become little hard if you get errors installing or running new rails app. 

    5.Other components installed:

    	* I installed Sublime Text Editor to work on code. 
    	* Needed to install jdk to implement java code used.

    6. To deploy and run server:

    	* To run project, ruby on rails and jdk environment is required. 
    	* Open terminal and using cd command open the project folder.
    	* Then, we have to run the server which is done using command: rails server or rails s
    	* Open browser and enter the localhost address with port that server showed on running
        (http://localhost:3000)
  		* Home page has a button and map with three markers.
  		* Click the button and JSON objects are returned in table format.
      * Click a marker on the map and it displays the place and nameof object in an infowindow.

