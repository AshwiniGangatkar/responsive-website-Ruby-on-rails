# Be sure to restart your server when you modify this file.

Rochan::Application.config.session_store :cookie_store, key: '_rochan_session'
