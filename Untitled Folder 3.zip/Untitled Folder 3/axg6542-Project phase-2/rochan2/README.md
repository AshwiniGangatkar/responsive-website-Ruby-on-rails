== README

This README would normally document whatever steps are necessary to get the
application up and running.

To fetch the data from third party I used jquery code to fetch and the code is stored by name ex.html.

In project named rochan SQL queries can be executed.
In project named rochan1 NOSQL queries can be executed.

1. What SQL framework did you choose and why?
       For SQL framework I used SQLite3 which is an inbuilt database for ruby on rails. SQLite3 is a serverless and I had no configuration to do.
                                          
2. What NOSQL framework did you choose and why?
       For NOSQL framework  I choose Mongodb.

3. What server framework did you choose and why?
       For server framework I choose Ruby on Rails because it as an inbuilt server and coding in ruby is very easy[less code needded].
       ruby version 2.2.1p85
       rails version 4.2.1

4. What aspect of the implementation did you find easy, if any and why?
       Implementation of getting the data and transfering to SQLite database was very easy and querying the database using query language
       was simple, their was no need to learn any extra query language specific to ruby.

5. What aspect of the implementation did you find hard, if any and why?
       Downloading Mongodb was difficult because it required more disk space. So installing it on windows and connecting to ruby was     difficult because I didnt know how to do that. Finally refering articles olnine and watching online videos were helpful.
    
6. What components other than SQL, NOSQL and server framework did you install, if any, and if so, what is their purpose for your solution.
       No, I didnot install anything apart from SQL and NOSQL.

7. What ubuntu commands are required to deploy and run your server?
  1. To execute SQL queries on terminal:
        1. change the folder where my project exist.
        2. rake db:migrate
        3. rake db:seed
        4. rails dbconsole
        5. Select * from firsts;
        6. select * from firsts where name='USDVND';
  2. To execute NOSQL queries on terminal:
        1. change the folder where my project exist.
        2. rake db:migrate
        3. rake db:seeds
    establish a connection with mongod by executing
     1. mongod.exe
     2. mongo
     
    from command prompt queries are executed once after mongo connection is established.
        4. db.kvs.find({_id:objectId("552570d26a61730cb013000")})       #[id value may change]
        5. db.kvs.find({name:"USDVND"})
        
