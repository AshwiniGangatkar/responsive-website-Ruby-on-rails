class Kv
  include Mongoid::Document
  field :name, type: String
  field :price, type: String
  field :symbol, type: String
  field :ts, type: String
  field :utctime, type: String
  field :volume, type: String
end
