require 'test_helper'

class FirstTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
