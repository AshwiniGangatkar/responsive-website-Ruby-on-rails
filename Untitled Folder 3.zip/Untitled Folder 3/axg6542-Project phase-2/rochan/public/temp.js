{
"name" : "USD/KRW",
"price" : "1085.800049",
"symbol" : "KRW=X",
"ts" : "1428290890",
"type" : "currency",
"utctime" : "2015-04-06T03:28:10+0000",
"volume" : "0"
}


,
{

"name" : "SILVER 1 OZ 999 NY",
"price" : "0.059930",
"symbol" : "XAG=X",
"ts" : "1428011531",
"type" : "currency",
"utctime" : "2015-04-02T21:52:11+0000",
"volume" : "100"
}

,
{

"name" : "USD/VND",
"price" : "21595.000000",
"symbol" : "VND=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/BOB",
"price" : "6.910000",
"symbol" : "BOB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MOP",
"price" : "7.985000",
"symbol" : "MOP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/BDT",
"price" : "76.585953",
"symbol" : "BDT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/MDL",
"price" : "17.400000",
"symbol" : "MDL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/VEF",
"price" : "6.350000",
"symbol" : "VEF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GEL",
"price" : "2.256400",
"symbol" : "GEL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/ISK",
"price" : "134.095001",
"symbol" : "ISK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/BYR",
"price" : "14600.000000",
"symbol" : "BYR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/THB",
"price" : "32.169498",
"symbol" : "THB=X",
"ts" : "1428290880",
"type" : "currency",
"utctime" : "2015-04-06T03:28:00+0000",
"volume" : "0"

}
,
{
{ 
"name" : "USD/MXV ",
"price" : "2.810000",
"symbol" : "MXV=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
{ 
"name" : "USD/TND",
"price" : "1.944150",
"symbol" : "TND=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/JMD",
"price" : "114.705002",
"symbol" : "JMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/DKK",
"price" : "6.806300",
"symbol" : "DKK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"

}
,

"name" : "USD/SRD",
"price" : "3.300000",
"symbol" : "SRD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BWP",
"price" : "9.741150",
"symbol" : "BWP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/NOK",
"price" : "7.929400",
"symbol" : "NOK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/MUR",
"price" : "36.400002",
"symbol" : "MUR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/AZN",
"price" : "1.046250",
"symbol" : "AZN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/INR",
"price" : "62.064999",
"symbol" : "INR=X",
"ts" : "1428290840",
"type" : "currency",
"utctime" : "2015-04-06T03:27:20+0000",
"volume" : "0"

}
,
{

"name" : "USD/MGA",
"price" : "3009.649902",
"symbol" : "MGA=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
"
"name" : "USD/CAD",
"price" : "1.247655",
"symbol" : "CAD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/XAF",
"price" : "597.329163",
"symbol" : "XAF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/LBP",
"price" : "1512.000000",
"symbol" : "LBP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/XDR",
"price" : "0.718550",
"symbol" : "XDR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/IDR",
"price" : "12937.500000",
"symbol" : "IDR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/IEP",
"price" : "0.717154",
"symbol" : "IEP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/AUD",
"price" : "1.312422",
"symbol" : "AUD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/MMK",
"price" : "1028.500000",
"symbol" : "MMK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LYD",
"price" : "1.347650",
"symbol" : "LYD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ZAR",
"price" : "11.782650",
"symbol" : "ZAR=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/IQD",
"price" : "1145.799927",
"symbol" : "IQD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/XPF",
"price" : "108.666153",
"symbol" : "XPF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TJS",
"price" : "5.967100",
"symbol" : "TJS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CUP",
"price" : "1.000000",
"symbol" : "CUP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/UGX",
"price" : "3000.000000",
"symbol" : "UGX=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/NGN",
"price" : "199.050003",
"symbol" : "NGN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/PGK",
"price" : "2.678450",
"symbol" : "PGK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TOP",
"price" : "1.986080",
"symbol" : "TOP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KES",
"price" : "91.433998",
"symbol" : "KES=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/TMT",
"price" : "3.500000",
"symbol" : "TMT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/CRC",
"price" : "532.830017",
"symbol" : "CRC=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MZN",
"price" : "36.500000",
"symbol" : "MZN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SYP",
"price" : "188.929001",
"symbol" : "SYP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ANG",
"price" : "1.790000",
"symbol" : "ANG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ZMW",
"price" : "7.590000",
"symbol" : "ZMW=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BRL",
"price" : "3.104200",
"symbol" : "BRL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/BSD",
"price" : "1.000000",
"symbol" : "BSD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/NIO",
"price" : "26.941900",
"symbol" : "NIO=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GNF",
"price" : "7250.000000",
"symbol" : "GNF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/BMD",
"price" : "1.000000",
"symbol" : "BMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SLL",
"price" : "4345.000000",
"symbol" : "SLL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MKD",
"price" : "56.115002",
"symbol" : "MKD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BIF",
"price" : "1570.000000",
"symbol" : "BIF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/LAK",
"price" : "7988.299805",
"symbol" : "LAK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BHD",
"price" : "0.373600",
"symbol" : "BHD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SHP",
"price" : "0.670300",
"symbol" : "SHP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BGN",
"price" : "1.781300",
"symbol" : "BGN=X",
"ts" : "1428290860",
"type" : "currency",
"utctime" : "2015-04-06T03:27:40+0000",
"volume" : "0"
}

,
{

"name" : "USD/SGD",
"price" : "1.352700",
"symbol" : "SGD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CNY",
"price" : "6.143250",
"symbol" : "CNY=X",
"ts" : "1428290840",
"type" : "currency",
"utctime" : "2015-04-06T03:27:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/EUR",
"price" : "0.910722",
"symbol" : "EUR=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TTD",
"price" : "6.371000",
"symbol" : "TTD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SCR",
"price" : "13.329950",
"symbol" : "SCR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BBD",
"price" : "2.000000",
"symbol" : "BBD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

 
"name" : "USD/SBD",
"price" : "7.783162",
"symbol" : "SBD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MAD",
"price" : "9.757000",
"symbol" : "MAD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/GTQ",
"price" : "7.641500",
"symbol" : "GTQ=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MWK",
"price" : "435.575012",
"symbol" : "MWK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/PKR",
"price" : "101.834999",
"symbol" : "PKR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ITL",
"price" : "1763.210815",
"symbol" : "ITL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/PEN",
"price" : "3.094500",
"symbol" : "PEN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/AED",
"price" : "3.673150",
"symbol" : "AED=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LVL",
"price" : "0.640000",
"symbol" : "LVL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "PALLADIUM 1 OZ",
"price" : "0.001340",
"symbol" : "XPD=X",
"ts" : "1428011531",
"type" : "currency",
"utctime" : "2015-04-02T21:52:11+0000",
"volume" : "0"
}

,
{

"name" : "USD/UAH",
"price" : "23.392950",
"symbol" : "UAH=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LRD",
"price" : "84.660004",
"symbol" : "LRD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/FRF",
"price" : "5.973300",
"symbol" : "FRF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LSL",
"price" : "11.775250",
"symbol" : "LSL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SEK",
"price" : "8.547150",
"symbol" : "SEK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/RON",
"price" : "4.027000",
"symbol" : "RON=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/XOF",
"price" : "597.329163",
"symbol" : "XOF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/COP",
"price" : "2533.800049",
"symbol" : "COP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CDF",
"price" : "925.000000",
"symbol" : "CDF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/USD",
"price" : "1.000000",
"symbol" : "USD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/TZS",
"price" : "1825.900024",
"symbol" : "TZS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/NPR",
"price" : "100.129997",
"symbol" : "NPR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GHS",
"price" : "3.835000",
"symbol" : "GHS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ZWL",
"price" : "322.355011",
"symbol" : "ZWL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/SOS",
"price" : "698.349976",
"symbol" : "SOS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/DZD",
"price" : "96.300003",
"symbol" : "DZD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LKR",
"price" : "130.910004",
"symbol" : "LKR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/FKP",
"price" : "0.647000",
"symbol" : "FKP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/JPY",
"price" : "119.082497",
"symbol" : "JPY=X",
"ts" : "1428290860",
"type" : "currency",
"utctime" : "2015-04-06T03:27:40+0000",
"volume" : "0"
}

,
{

"name" : "USD/CHF",
"price" : "0.952700",
"symbol" : "CHF=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KYD",
"price" : "0.820000",
"symbol" : "KYD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/CLP",
"price" : "615.395020",
"symbol" : "CLP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/IRR",
"price" : "28084.000000",
"symbol" : "IRR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/AFN",
"price" : "57.880001",
"symbol" : "AFN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/DJF",
"price" : "177.720001",
"symbol" : "DJF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SVC",
"price" : "8.745000",
"symbol" : "SVC=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/PLN",
"price" : "3.699200",
"symbol" : "PLN=X",
"ts" : "1428290896",
"type" : "currency",
"utctime" : "2015-04-06T03:28:16+0000",
"volume" : "0"
}

,
{

"name" : "USD/PYG",
"price" : "4839.720215",
"symbol" : "PYG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ERN",
"price" : "15.279000",
"symbol" : "ERN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ETB",
"price" : "20.442499",
"symbol" : "ETB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ILS",
"price" : "3.923600",
"symbol" : "ILS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TWD",
"price" : "30.930000",
"symbol" : "TWD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/KPW",
"price" : "900.000000",
"symbol" : "KPW=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GIP",
"price" : "0.670300",
"symbol" : "GIP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SIT",
"price" : "218.221603",
"symbol" : "SIT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BND",
"price" : "1.353050",
"symbol" : "BND=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/HNL",
"price" : "21.350000",
"symbol" : "HNL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/CZK",
"price" : "25.079000",
"symbol" : "CZK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/HUF",
"price" : "272.359985",
"symbol" : "HUF=X",
"ts" : "1428290896",
"type" : "currency",
"utctime" : "2015-04-06T03:28:16+0000",
"volume" : "0"
}

,
{

"name" : "USD/BZD",
"price" : "1.995000",
"symbol" : "BZD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/DEM",
"price" : "1.781050",
"symbol" : "DEM=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/JOD",
"price" : "0.708150",
"symbol" : "JOD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/RWF",
"price" : "689.000000",
"symbol" : "RWF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LTL",
"price" : "2.934000",
"symbol" : "LTL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/RUB",
"price" : "57.089500",
"symbol" : "RUB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/RSD",
"price" : "109.379997",
"symbol" : "RSD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/WST",
"price" : "2.474551",
"symbol" : "WST=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "PLATINUM 1 UZ 999",
"price" : "0.000867",
"symbol" : "XPT=X",
"ts" : "1428011531",
"type" : "currency",
"utctime" : "2015-04-02T21:52:11+0000",
"volume" : "129"
}

,
{

"name" : "USD/PAB",
"price" : "1.000000",
"symbol" : "PAB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/NAD",
"price" : "11.775250",
"symbol" : "NAD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/DOP",
"price" : "44.674999",
"symbol" : "DOP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ALL",
"price" : "127.824501",
"symbol" : "ALL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/HTG",
"price" : "47.313301",
"symbol" : "HTG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KMF",
"price" : "447.996887",
"symbol" : "KMF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/AMD",
"price" : "473.049988",
"symbol" : "AMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MRO",
"price" : "315.000000",
"symbol" : "MRO=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/HRK",
"price" : "6.942100",
"symbol" : "HRK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ECS",
"price" : "25000.000000",
"symbol" : "ECS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KHR",
"price" : "3942.199951",
"symbol" : "KHR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/PHP",
"price" : "44.384998",
"symbol" : "PHP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CYP",
"price" : "0.532950",
"symbol" : "CYP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/KWD",
"price" : "0.300470",
"symbol" : "KWD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/XCD",
"price" : "2.700000",
"symbol" : "XCD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "COPPER HIGHGRADE",
"price" : "0.362319",
"symbol" : "XCP=X",
"ts" : "1428289623",
"type" : "currency",
"utctime" : "2015-04-06T03:07:03+0000",
"volume" : "175"

}
,
{
 
"name" : "USD/CNH",
"price" : "6.197750",
"symbol" : "CNH=X",
"ts" : "1428290840",
"type" : "currency",
"utctime" : "2015-04-06T03:27:20+0000",
"volume" : "0"

}
,
{

"name" : "USD/SDG",
"price" : "5.975000",
"symbol" : "SDG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/CLF",
"price" : "0.024600",
"symbol" : "CLF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/KZT",
"price" : "185.895004",
"symbol" : "KZT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/TRY",
"price" : "2.567050",
"symbol" : "TRY=X",
"ts" : "1428290891",
"type" : "currency",
"utctime" : "2015-04-06T03:28:11+0000",
"volume" : "0"

}
,
{

"name" : "USD/NZD",
"price" : "1.315946",
"symbol" : "NZD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/FJD",
"price" : "2.061950",
"symbol" : "FJD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/BAM",
"price" : "1.781050",
"symbol" : "BAM=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/BTN",
"price" : "62.581249",
"symbol" : "BTN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/STD",
"price" : "22292.500000",
"symbol" : "STD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/VUV",
"price" : "108.364998",
"symbol" : "VUV=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/MVR",
"price" : "15.340000",
"symbol" : "MVR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/AOA",
"price" : "108.250000",
"symbol" : "AOA=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/EGP",
"price" : "7.630000",
"symbol" : "EGP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/QAR",
"price" : "3.639950",
"symbol" : "QAR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/OMR",
"price" : "0.385000",
"symbol" : "OMR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,

{ 
"name" : "USD/CVE",
"price" : "100.379997",
"symbol" : "CVE=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KGS",
"price" : "63.888901",
"symbol" : "KGS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MXN",
"price" : "14.822600",
"symbol" : "MXN=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MYR",
"price" : "3.639000",
"symbol" : "MYR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/GYD",
"price" : "207.210007",
"symbol" : "GYD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,

{ 
"name" : "USD/SZL",
"price" : "11.775250",
"symbol" : "SZL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/YER",
"price" : "215.059998",
"symbol" : "YER=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/SAR",
"price" : "3.750950",
"symbol" : "SAR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/UYU",
"price" : "25.695000",
"symbol" : "UYU=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GBP",
"price" : "0.670223",
"symbol" : "GBP=X",
"ts" : "1428290890",
"type" : "currency",
"utctime" : "2015-04-06T03:28:10+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/UZS",
"price" : "2490.199951",
"symbol" : "UZS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GMD",
"price" : "42.930000",
"symbol" : "GMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/AWG",
"price" : "1.790000",
"symbol" : "AWG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MNT",
"price" : "1983.000000",
"symbol" : "MNT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

{
 
"name" : "GOLD 1 OZ",
"price" : "0.000822",
"symbol" : "XAU=X",
"ts" : "1428290874",
"type" : "currency",
"utctime" : "2015-04-06T03:27:54+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/HKD",
"price" : "7.752400",
"symbol" : "HKD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ARS",
"price" : "8.762050",
"symbol" : "ARS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

{
"name" : "USD/KRW",
"price" : "1085.800049",
"symbol" : "KRW=X",
"ts" : "1428290890",
"type" : "currency",
"utctime" : "2015-04-06T03:28:10+0000",
"volume" : "0"
}


,
{

"name" : "SILVER 1 OZ 999 NY",
"price" : "0.059930",
"symbol" : "XAG=X",
"ts" : "1428011531",
"type" : "currency",
"utctime" : "2015-04-02T21:52:11+0000",
"volume" : "100"
}

,
{

"name" : "USD/VND",
"price" : "21595.000000",
"symbol" : "VND=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/BOB",
"price" : "6.910000",
"symbol" : "BOB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MOP",
"price" : "7.985000",
"symbol" : "MOP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/BDT",
"price" : "76.585953",
"symbol" : "BDT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/MDL",
"price" : "17.400000",
"symbol" : "MDL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/VEF",
"price" : "6.350000",
"symbol" : "VEF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GEL",
"price" : "2.256400",
"symbol" : "GEL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/ISK",
"price" : "134.095001",
"symbol" : "ISK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/BYR",
"price" : "14600.000000",
"symbol" : "BYR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/THB",
"price" : "32.169498",
"symbol" : "THB=X",
"ts" : "1428290880",
"type" : "currency",
"utctime" : "2015-04-06T03:28:00+0000",
"volume" : "0"

}
,
{
{ 
"name" : "USD/MXV ",
"price" : "2.810000",
"symbol" : "MXV=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
{ 
"name" : "USD/TND",
"price" : "1.944150",
"symbol" : "TND=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/JMD",
"price" : "114.705002",
"symbol" : "JMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/DKK",
"price" : "6.806300",
"symbol" : "DKK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"

}
,

"name" : "USD/SRD",
"price" : "3.300000",
"symbol" : "SRD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BWP",
"price" : "9.741150",
"symbol" : "BWP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/NOK",
"price" : "7.929400",
"symbol" : "NOK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/MUR",
"price" : "36.400002",
"symbol" : "MUR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/AZN",
"price" : "1.046250",
"symbol" : "AZN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/INR",
"price" : "62.064999",
"symbol" : "INR=X",
"ts" : "1428290840",
"type" : "currency",
"utctime" : "2015-04-06T03:27:20+0000",
"volume" : "0"

}
,
{

"name" : "USD/MGA",
"price" : "3009.649902",
"symbol" : "MGA=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
"
"name" : "USD/CAD",
"price" : "1.247655",
"symbol" : "CAD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/XAF",
"price" : "597.329163",
"symbol" : "XAF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/LBP",
"price" : "1512.000000",
"symbol" : "LBP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/XDR",
"price" : "0.718550",
"symbol" : "XDR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/IDR",
"price" : "12937.500000",
"symbol" : "IDR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/IEP",
"price" : "0.717154",
"symbol" : "IEP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/AUD",
"price" : "1.312422",
"symbol" : "AUD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/MMK",
"price" : "1028.500000",
"symbol" : "MMK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LYD",
"price" : "1.347650",
"symbol" : "LYD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ZAR",
"price" : "11.782650",
"symbol" : "ZAR=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/IQD",
"price" : "1145.799927",
"symbol" : "IQD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/XPF",
"price" : "108.666153",
"symbol" : "XPF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TJS",
"price" : "5.967100",
"symbol" : "TJS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CUP",
"price" : "1.000000",
"symbol" : "CUP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/UGX",
"price" : "3000.000000",
"symbol" : "UGX=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/NGN",
"price" : "199.050003",
"symbol" : "NGN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/PGK",
"price" : "2.678450",
"symbol" : "PGK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TOP",
"price" : "1.986080",
"symbol" : "TOP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KES",
"price" : "91.433998",
"symbol" : "KES=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/TMT",
"price" : "3.500000",
"symbol" : "TMT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/CRC",
"price" : "532.830017",
"symbol" : "CRC=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MZN",
"price" : "36.500000",
"symbol" : "MZN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SYP",
"price" : "188.929001",
"symbol" : "SYP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ANG",
"price" : "1.790000",
"symbol" : "ANG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ZMW",
"price" : "7.590000",
"symbol" : "ZMW=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BRL",
"price" : "3.104200",
"symbol" : "BRL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/BSD",
"price" : "1.000000",
"symbol" : "BSD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/NIO",
"price" : "26.941900",
"symbol" : "NIO=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GNF",
"price" : "7250.000000",
"symbol" : "GNF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/BMD",
"price" : "1.000000",
"symbol" : "BMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SLL",
"price" : "4345.000000",
"symbol" : "SLL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MKD",
"price" : "56.115002",
"symbol" : "MKD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BIF",
"price" : "1570.000000",
"symbol" : "BIF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/LAK",
"price" : "7988.299805",
"symbol" : "LAK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BHD",
"price" : "0.373600",
"symbol" : "BHD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SHP",
"price" : "0.670300",
"symbol" : "SHP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BGN",
"price" : "1.781300",
"symbol" : "BGN=X",
"ts" : "1428290860",
"type" : "currency",
"utctime" : "2015-04-06T03:27:40+0000",
"volume" : "0"
}

,
{

"name" : "USD/SGD",
"price" : "1.352700",
"symbol" : "SGD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CNY",
"price" : "6.143250",
"symbol" : "CNY=X",
"ts" : "1428290840",
"type" : "currency",
"utctime" : "2015-04-06T03:27:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/EUR",
"price" : "0.910722",
"symbol" : "EUR=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TTD",
"price" : "6.371000",
"symbol" : "TTD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SCR",
"price" : "13.329950",
"symbol" : "SCR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BBD",
"price" : "2.000000",
"symbol" : "BBD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

 
"name" : "USD/SBD",
"price" : "7.783162",
"symbol" : "SBD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MAD",
"price" : "9.757000",
"symbol" : "MAD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/GTQ",
"price" : "7.641500",
"symbol" : "GTQ=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MWK",
"price" : "435.575012",
"symbol" : "MWK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/PKR",
"price" : "101.834999",
"symbol" : "PKR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ITL",
"price" : "1763.210815",
"symbol" : "ITL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/PEN",
"price" : "3.094500",
"symbol" : "PEN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/AED",
"price" : "3.673150",
"symbol" : "AED=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LVL",
"price" : "0.640000",
"symbol" : "LVL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "PALLADIUM 1 OZ",
"price" : "0.001340",
"symbol" : "XPD=X",
"ts" : "1428011531",
"type" : "currency",
"utctime" : "2015-04-02T21:52:11+0000",
"volume" : "0"
}

,
{

"name" : "USD/UAH",
"price" : "23.392950",
"symbol" : "UAH=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LRD",
"price" : "84.660004",
"symbol" : "LRD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/FRF",
"price" : "5.973300",
"symbol" : "FRF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LSL",
"price" : "11.775250",
"symbol" : "LSL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SEK",
"price" : "8.547150",
"symbol" : "SEK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/RON",
"price" : "4.027000",
"symbol" : "RON=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/XOF",
"price" : "597.329163",
"symbol" : "XOF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/COP",
"price" : "2533.800049",
"symbol" : "COP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CDF",
"price" : "925.000000",
"symbol" : "CDF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/USD",
"price" : "1.000000",
"symbol" : "USD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/TZS",
"price" : "1825.900024",
"symbol" : "TZS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/NPR",
"price" : "100.129997",
"symbol" : "NPR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GHS",
"price" : "3.835000",
"symbol" : "GHS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ZWL",
"price" : "322.355011",
"symbol" : "ZWL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/SOS",
"price" : "698.349976",
"symbol" : "SOS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/DZD",
"price" : "96.300003",
"symbol" : "DZD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LKR",
"price" : "130.910004",
"symbol" : "LKR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/FKP",
"price" : "0.647000",
"symbol" : "FKP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/JPY",
"price" : "119.082497",
"symbol" : "JPY=X",
"ts" : "1428290860",
"type" : "currency",
"utctime" : "2015-04-06T03:27:40+0000",
"volume" : "0"
}

,
{

"name" : "USD/CHF",
"price" : "0.952700",
"symbol" : "CHF=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KYD",
"price" : "0.820000",
"symbol" : "KYD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/CLP",
"price" : "615.395020",
"symbol" : "CLP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/IRR",
"price" : "28084.000000",
"symbol" : "IRR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/AFN",
"price" : "57.880001",
"symbol" : "AFN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/DJF",
"price" : "177.720001",
"symbol" : "DJF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SVC",
"price" : "8.745000",
"symbol" : "SVC=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/PLN",
"price" : "3.699200",
"symbol" : "PLN=X",
"ts" : "1428290896",
"type" : "currency",
"utctime" : "2015-04-06T03:28:16+0000",
"volume" : "0"
}

,
{

"name" : "USD/PYG",
"price" : "4839.720215",
"symbol" : "PYG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ERN",
"price" : "15.279000",
"symbol" : "ERN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ETB",
"price" : "20.442499",
"symbol" : "ETB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ILS",
"price" : "3.923600",
"symbol" : "ILS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/TWD",
"price" : "30.930000",
"symbol" : "TWD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/KPW",
"price" : "900.000000",
"symbol" : "KPW=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GIP",
"price" : "0.670300",
"symbol" : "GIP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/SIT",
"price" : "218.221603",
"symbol" : "SIT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/BND",
"price" : "1.353050",
"symbol" : "BND=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/HNL",
"price" : "21.350000",
"symbol" : "HNL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/CZK",
"price" : "25.079000",
"symbol" : "CZK=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{

"name" : "USD/HUF",
"price" : "272.359985",
"symbol" : "HUF=X",
"ts" : "1428290896",
"type" : "currency",
"utctime" : "2015-04-06T03:28:16+0000",
"volume" : "0"
}

,
{

"name" : "USD/BZD",
"price" : "1.995000",
"symbol" : "BZD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/DEM",
"price" : "1.781050",
"symbol" : "DEM=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/JOD",
"price" : "0.708150",
"symbol" : "JOD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/RWF",
"price" : "689.000000",
"symbol" : "RWF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/LTL",
"price" : "2.934000",
"symbol" : "LTL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/RUB",
"price" : "57.089500",
"symbol" : "RUB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/RSD",
"price" : "109.379997",
"symbol" : "RSD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/WST",
"price" : "2.474551",
"symbol" : "WST=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "PLATINUM 1 UZ 999",
"price" : "0.000867",
"symbol" : "XPT=X",
"ts" : "1428011531",
"type" : "currency",
"utctime" : "2015-04-02T21:52:11+0000",
"volume" : "129"
}

,
{

"name" : "USD/PAB",
"price" : "1.000000",
"symbol" : "PAB=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/NAD",
"price" : "11.775250",
"symbol" : "NAD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/DOP",
"price" : "44.674999",
"symbol" : "DOP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/ALL",
"price" : "127.824501",
"symbol" : "ALL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/HTG",
"price" : "47.313301",
"symbol" : "HTG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KMF",
"price" : "447.996887",
"symbol" : "KMF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/AMD",
"price" : "473.049988",
"symbol" : "AMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MRO",
"price" : "315.000000",
"symbol" : "MRO=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/HRK",
"price" : "6.942100",
"symbol" : "HRK=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ECS",
"price" : "25000.000000",
"symbol" : "ECS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KHR",
"price" : "3942.199951",
"symbol" : "KHR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/PHP",
"price" : "44.384998",
"symbol" : "PHP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/CYP",
"price" : "0.532950",
"symbol" : "CYP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/KWD",
"price" : "0.300470",
"symbol" : "KWD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/XCD",
"price" : "2.700000",
"symbol" : "XCD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "COPPER HIGHGRADE",
"price" : "0.362319",
"symbol" : "XCP=X",
"ts" : "1428289623",
"type" : "currency",
"utctime" : "2015-04-06T03:07:03+0000",
"volume" : "175"

}
,
{
 
"name" : "USD/CNH",
"price" : "6.197750",
"symbol" : "CNH=X",
"ts" : "1428290840",
"type" : "currency",
"utctime" : "2015-04-06T03:27:20+0000",
"volume" : "0"

}
,
{

"name" : "USD/SDG",
"price" : "5.975000",
"symbol" : "SDG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/CLF",
"price" : "0.024600",
"symbol" : "CLF=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/KZT",
"price" : "185.895004",
"symbol" : "KZT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/TRY",
"price" : "2.567050",
"symbol" : "TRY=X",
"ts" : "1428290891",
"type" : "currency",
"utctime" : "2015-04-06T03:28:11+0000",
"volume" : "0"

}
,
{

"name" : "USD/NZD",
"price" : "1.315946",
"symbol" : "NZD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/FJD",
"price" : "2.061950",
"symbol" : "FJD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/BAM",
"price" : "1.781050",
"symbol" : "BAM=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/BTN",
"price" : "62.581249",
"symbol" : "BTN=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/STD",
"price" : "22292.500000",
"symbol" : "STD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/VUV",
"price" : "108.364998",
"symbol" : "VUV=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{

"name" : "USD/MVR",
"price" : "15.340000",
"symbol" : "MVR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/AOA",
"price" : "108.250000",
"symbol" : "AOA=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"

}
,
{
 
"name" : "USD/EGP",
"price" : "7.630000",
"symbol" : "EGP=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/QAR",
"price" : "3.639950",
"symbol" : "QAR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/OMR",
"price" : "0.385000",
"symbol" : "OMR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,

{ 
"name" : "USD/CVE",
"price" : "100.379997",
"symbol" : "CVE=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/KGS",
"price" : "63.888901",
"symbol" : "KGS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MXN",
"price" : "14.822600",
"symbol" : "MXN=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/MYR",
"price" : "3.639000",
"symbol" : "MYR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/GYD",
"price" : "207.210007",
"symbol" : "GYD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,

{ 
"name" : "USD/SZL",
"price" : "11.775250",
"symbol" : "SZL=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/YER",
"price" : "215.059998",
"symbol" : "YER=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/SAR",
"price" : "3.750950",
"symbol" : "SAR=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/UYU",
"price" : "25.695000",
"symbol" : "UYU=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GBP",
"price" : "0.670223",
"symbol" : "GBP=X",
"ts" : "1428290890",
"type" : "currency",
"utctime" : "2015-04-06T03:28:10+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/UZS",
"price" : "2490.199951",
"symbol" : "UZS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/GMD",
"price" : "42.930000",
"symbol" : "GMD=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/AWG",
"price" : "1.790000",
"symbol" : "AWG=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

,
{

"name" : "USD/MNT",
"price" : "1983.000000",
"symbol" : "MNT=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}

{
 
"name" : "GOLD 1 OZ",
"price" : "0.000822",
"symbol" : "XAU=X",
"ts" : "1428290874",
"type" : "currency",
"utctime" : "2015-04-06T03:27:54+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/HKD",
"price" : "7.752400",
"symbol" : "HKD=X",
"ts" : "1428290900",
"type" : "currency",
"utctime" : "2015-04-06T03:28:20+0000",
"volume" : "0"
}

,
{
 
"name" : "USD/ARS",
"price" : "8.762050",
"symbol" : "ARS=X",
"ts" : "1428290820",
"type" : "currency",
"utctime" : "2015-04-06T03:27:00+0000",
"volume" : "0"
}
