class First < ActiveRecord::Base

end
