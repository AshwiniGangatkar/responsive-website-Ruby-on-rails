class RochanController < ApplicationController
	require 'json'
	
  #def index
  #@input = HTTParty.get("http://finance.yahoo.com/webservice/v1/symbols/allcurrencies/quote?format=json")
  #@input1 = JSON.parse(@input.body)
   #puts @input1
  
  #end
#end


