require 'sqlite3' 
begin dbh = SQLite3::Database.new "development.sqlite3"
 key =
 statem = dbh.prepare "SELECT * FROM poornimas where Id < ?" 
 statem.bind_param 1, id 
 r1 = st.execute
 tuples = r1 puts tuples.join "\s" 
while(tuples = r1.next) do 
 puts tuples.join "\s"
 end
rescue SQLite3::Exception => e 
 puts "Exception occurred while executing the query"
 puts e 
ensure 
 statem.close
 if
 statem dbh.close 
if
 dbh
end
