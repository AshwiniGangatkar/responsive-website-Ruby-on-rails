class CreateFirsts < ActiveRecord::Migration
  def change
    create_table :firsts do |t|
      t.string :name
      t.string :price
      t.string :symbol
      t.string :ts
      t.string :utctime
      t.string :volume
      t.timestamps
    end
  end
end
