#!/usr/bin/ruby
require 'sqlite3'
 begin 
 dbh = SQLite3::Database.new "development.sqlite3"
 key =10
 statem = dbh.prepare "SELECT * FROM firsts where Id = ?" 
 statem.bind_param 1, key
 r1 = statem.execute
 tuples = r1 
 puts tuples.join "\s" 

rescue SQLite3::Exception => e
 puts "Exception occurred while executing the query" 
 puts e 
ensure 
 statem.close if statem 
 dbh.close if dbh
end
